import setuptools

setuptools.setup(
    name="jasn1",
    version="0.0.1",
    author="Matthew Laurence Willaim Graham",
    description="Parsing ASN.1 data to JSON and vice-versa",
    packages=["jasn1"]
)
